const MIME_MAP: Record<string, string> = {
  png: 'image/png',
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  gif: 'image/gif',
  bmp: 'image/bmp',
  webp: 'image/webp',
  svg: 'image/svg+xml',
  heic: 'image/heic',
  heif: 'image/heif'
};

const DEFAULT_MIME = 'image/jpeg';

const getMimeType = (attachmentName?: string | null): string => {
  if (!attachmentName) {
    return DEFAULT_MIME;
  }

  const ext = attachmentName.split('.').pop()?.toLowerCase();
  if (ext && MIME_MAP[ext]) {
    return MIME_MAP[ext];
  }

  return DEFAULT_MIME;
};

/**
 * Builds a data URL for base64 attachment strings.
 * If attachment already contains a data URI prefix, it is returned as-is.
 */
export const buildAttachmentSrc = (
  attachment?: string | null,
  attachmentName?: string | null
): string | null => {
  if (!attachment) {
    return null;
  }

  const trimmed = attachment.trim();
  if (!trimmed) {
    return null;
  }

  if (trimmed.startsWith('data:') || trimmed.startsWith('http://') || trimmed.startsWith('https://')) {
    return trimmed;
  }

  const mimeType = getMimeType(attachmentName);
  return `data:${mimeType};base64,${trimmed}`;
};

