import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/Layout';
import { AuthProvider, useAuth } from './components/AuthProvider';

// Pages
import { DashboardPage } from './pages/dashboard/DashboardPage';
import { LoginPage } from './pages/auth/LoginPage';
import { OpenTickets } from './pages/ticketmanagement/OpenTickets';
import {  ResolvedTickets } from './pages/ticketmanagement/ClosedTickets';
import { AllTickets } from './pages/ticketmanagement/AllTickets';
import { TicketDetailPage } from './pages/ticketmanagement/TicketDetailPage';
import { FaqPage } from './pages/faqs/FaqPage';
import { LicensePage } from './pages/license/LicensePage';

const ProtectedRoute = ({ children }: { children?: React.ReactNode }) => {
  const { isAuthenticated } = useAuth();
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  return <Layout>{children}</Layout>;
};

const AppRoutes = () => {
  const { isAuthenticated } = useAuth();

  return (
    <Routes>
      <Route path="/login" element={isAuthenticated ? <Navigate to="/tickets/open" replace /> : <LoginPage />} />
      
      {/* Dashboard */}
      {/* <Route
        path="/dashboard"
        element={
          <ProtectedRoute>
            <DashboardPage />
          </ProtectedRoute>
        }
      /> */}

      {/* Ticket Management */}
      <Route
        path="/tickets/open"
        element={
          <ProtectedRoute>
            <OpenTickets />
          </ProtectedRoute>
        }
      />
      <Route
        path="/tickets/closed"
        element={
          <ProtectedRoute>
            <ResolvedTickets />
          </ProtectedRoute>
        }
      />
      <Route
        path="/tickets/all"
        element={
          <ProtectedRoute>
            <AllTickets />
          </ProtectedRoute>
        }
      />
      <Route
        path="/tickets/:id"
        element={
          <ProtectedRoute>
            <TicketDetailPage />
          </ProtectedRoute>
        }
      />

      {/* Other Pages */}
      <Route
        path="/faqs"
        element={
          <ProtectedRoute>
            <FaqPage />
          </ProtectedRoute>
        }
      />
      {/* <Route
        path="/license"
        element={
          <ProtectedRoute>
            <LicensePage />
          </ProtectedRoute>
        }
      /> */}
      
      {/* Redirects */}
      <Route path="/" element={<Navigate to="/tickets/open" replace />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

const App: React.FC = () => {
  return (
    <AuthProvider>
      <HashRouter>
        <AppRoutes />
      </HashRouter>
    </AuthProvider>
  );
};

export default App;