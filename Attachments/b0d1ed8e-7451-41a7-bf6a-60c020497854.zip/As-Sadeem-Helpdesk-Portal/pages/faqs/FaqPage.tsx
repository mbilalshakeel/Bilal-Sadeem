import { Search } from "lucide-react";
import React, { useMemo, useState } from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  Input,
} from "../../components/ui-kit";

interface FAQItem {
  question: string;
  answer: string | React.ReactNode;
}

interface FAQCategory {
  title: string;
  items: FAQItem[];
}

const FAQ_DATA: FAQCategory[] = [
  {
    title: "Infrastructure as a Service (IaaS)",
    items: [
      {
        question: "What is Infrastructure as a Service (IaaS)?",
        answer:
          "CMP provides IaaS by enabling users to provision and manage virtual machines, storage, and networking resources through a unified interface.",
      },
      {
        question: "How do I provision resources under IaaS?",
        answer:
          "Resources can be provisioned via CMP UI by selecting instance type, and configuration.",
      },
      {
        question: "Are there limits on the number of instances I can create?",
        answer:
          "Limits can be set per tenant or user group within CMP by tenant admin to control resource usage. These quotas help manage capacity and prevent over-provisioning.",
      },
    ],
  },
  {
    title: "Storage as a Service",
    items: [
      {
        question: "What storage types are available (block, object, file)?",
        answer: "CMP supports block storage, object storage, and file shares.",
      },
      {
        question: "How do I attach storage to a virtual machine or container?",
        answer:
          "Storage can be attached during provisioning or afterward by editing the instance and adding new volumes.",
      },
      {
        question: "Is data encryption supported for storage services?",
        answer:
          "Yes, CMP supports encryption based on the underlying cloud capabilities and integrates with external key management systems.",
      },
    ],
  },
  {
    title: "Compute – Virtual Machine",
    items: [
      {
        question: "How do I create and manage virtual machines?",
        answer:
          "Navigate to the provisioning section in CMP, select the cloud and instance type, configure settings, and provision the VM. Management tasks include start, stop, resize, and delete operations.",
      },
      {
        question: "What operating systems are supported?",
        answer:
          "CMP supports a wide range of operating systems, including Linux distributions and Windows, depending on the available images.",
      },
      {
        question: "Can I resize my VM after creation?",
        answer:
          "Yes, VMs can be resized post-provisioning by selecting a different service plan or adjusting resources manually.",
      },
      {
        question: "How is VM billing calculated?",
        answer:
          "Billing is based on the selected service plan, resource usage, and duration. CMP has an integrated billing system to provide cost tracking and chargeback reports.",
      },
    ],
  },
  {
    title: "Container as a Service – Docker / Kubernetes Cluster",
    items: [
      {
        question:
          "What’s the difference between Docker and Kubernetes support?",
        answer:
          "CMP supports both Docker hosts and Kubernetes clusters. Docker is for containerizing apps on single hosts, while Kubernetes manages multi-container deployments across clusters.",
      },
      {
        question: "How do I deploy a Kubernetes cluster?",
        answer:
          "Navigate to the infrastructure section, choose Kubernetes, and configure the cluster settings of managed and custom clusters.",
      },
      {
        question: "Are persistent volumes supported in containers?",
        answer:
          "Yes, persistent volumes are supported through storage integration and persistent volume claim configuration within Kubernetes.",
      },
      {
        question: "How is autoscaling handled in Kubernetes clusters?",
        answer:
          "CMP integrates with Kubernetes’ autoscaling features, allowing clusters to scale based on resource usage and defined policies.",
      },
    ],
  },
  {
    title: "Load Balancer as a Service",
    items: [
      {
        question: "How do I create and configure a load balancer",
        answer:
          "User can’t create and configure load balancer; they can only use load balancer services and link them to instances or services.",
      },
      {
        question: "What protocols are supported (HTTP, HTTPS, TCP)?",
        answer:
          "Protocols supported include by default are HTTP, HTTPS, and TCP",
      },
      {
        question: "Can I use SSL termination on the load balancer?",
        answer:
          "Yes, CMP supports SSL termination, enabling the load balancer to decrypt SSL before routing traffic.",
      },
    ],
  },
  {
    title: "Backup as a Service",
    items: [
      {
        question: "How do I schedule regular backups?",
        answer:
          "Create backup jobs in CMP by defining the schedule, selecting the target resources, and configuring retention.",
      },
      {
        question: "Where are my backups stored, and are they encrypted?",
        answer:
          "Backups are stored in specified storage locations (e.g., buckets or file shares) with optional encryption depending on pre-configured provider settings.",
      },
      {
        question: "Can I restore individual files from a backup?",
        answer:
          "CMP allows restoring full instances or volumes. Restoring individual files requires manual mounting and extraction.",
      },
    ],
  },
  {
    title: "Identity and Access Management",
    items: [
      {
        question: "How do I manage users and roles?",
        answer:
          "Create backup jobs in CMP by defining the schedule, selecting the target resources, and configuring retention.",
      },
      {
        question: "Can I set permissions at the project or resource level?",
        answer:
          "Yes, CMP provides fine-grained role-based access control (RBAC) that supports project and resource-level permissions.",
      },
      {
        question: "Is multi-factor authentication (MFA) supported?",
        answer: "Yes, MFA is a default feature in CMP.",
      },
    ],
  },
  {
    title: "Security as a Service",
    items: [
      {
        question: "What security services are included?",
        answer:
          "Security features include RBAC, credential vaulting, audit logs, policy enforcement.",
      },
      {
        question:
          "Are security events or alerts generated for suspicious activity?",
        answer:
          "CMP logs security-related events and can integrate with SIEMs and monitoring tools for alerting.",
      },
      {
        question: "Can I run security scans on my resources?",
        answer:
          "Yes, CMP supports running security scans on virtual machines, containers, and other provisioned resources. These scans can help detect vulnerabilities, misconfigurations, or compliance violations. CMP can also integrate with external security tools to automate scanning and reporting.",
      },
    ],
  },
  {
    title: "App Blueprints Services",
    items: [
      {
        question: "What are app blueprints and how do I use them?",
        answer:
          "App blueprints define multi-tier app deployments with components, variables, and scripts. They automate and standardize deployment.",
      },
      {
        question: "Can I create custom blueprints for my application stack?",
        answer:
          "No, custom blueprints cannot be created, user can only use predefined blueprints.",
      },
      {
        question: "Are versioned deployments supported?",
        answer:
          "Yes, CMP supports blueprint versioning to manage changes over time.",
      },
    ],
  },
  {
    title: "Service Catalogue and Marketplace",
    items: [
      {
        question: "What types of services are available in the marketplace?",
        answer:
          "The catalog includes blueprints, workflows, and instance types pre-configured for easy self-service deployment.",
      },
      {
        question: "How do I deploy services from the catalogue?",
        answer:
          "Browse the catalog, select a service, configure input options, and deploy using a single click.",
      },
      {
        question: "Are third-party apps vetted for security and compliance?",
        answer:
          "Third-party apps are reviewed by admins before adding to ensure they meet security and compliance requirements.",
      },
    ],
  },
  {
    title: "Function as a Service (FaaS)",
    items: [
      {
        question:
          "What runtimes/languages are supported for serverless functions?",
        answer:
          "Supported runtimes include Python, Node.js, and others, depending on the configured FaaS backend (e.g., OpenFaaS).",
      },
      {
        question: "How do I trigger functions (HTTP, events, schedules)?",
        answer:
          "Functions can be triggered via HTTP calls, cloud events, or scheduled jobs defined in CMP.",
      },
      {
        question:
          "What are the execution time and resource limits for functions?",
        answer:
          "Limits depend on the FaaS provider and can be configured during function creation or deployment.",
      },
    ],
  },
  {
    title: "Monitoring and Logging",
    items: [
      {
        question: "How can I view resource usage and system metrics?",
        answer:
          "CMP provides dashboards and metrics for VMs, containers, and apps.",
      },
      {
        question: "Are logs centralized and searchable?",
        answer:
          "Yes, CMP aggregates logs from systems and comes with integrated with logging solutions for analysis.",
      },
      {
        question: "Can I set alerts based on logs or metrics thresholds?",
        answer:
          "Alerts can be configured based on thresholds for system metrics and events, enabling proactive monitoring and response.",
      },
    ],
  },
  {
    title: "Network as a Service – Floating IP",
    items: [
      {
        question: "What is a Floating IP and when should I use it?",
        answer:
          "A Floating IP is a public IP address that can be dynamically associated with instances. Use it to provide external access to instances in private networks.",
      },
      {
        question: "How do I associate a Floating IP with a VM?",
        answer:
          "During provisioning, select the option to assign a Floating IP. CMP does support assigning a Floating IP after the instance has been provisioned.",
      },
    ],
  },
  {
    title: "Platform as a Service (PaaS)",
    items: [
      {
        question: "What development environments are supported under PaaS?",
        answer:
          "Under PaaS, CMP provides users with operating system environments across multiple flavors of Linux and Windows. Supported Linux distributions include Ubuntu, Debian, Rocky Linux, AlmaLinux, etc., while supported Windows environments include Windows Server 2019, Windows Server 2022, Windows 10, etc. These ready-to-use environments allow developers to build, deploy, and run applications in the OS of their choice.",
      },
      {
        question: "Can I scale applications automatically?",
        answer:
          "Yes, autoscaling can be configured based on metrics such as CPU and memory usage.",
      },
    ],
  },
  {
    title: "Database as a Service (DBaaS)",
    items: [
      {
        question:
          "Which database engines are supported (MySQL, PostgreSQL, etc.)?",
        answer:
          "CMP supports engines like MySQL, PostgreSQL, MongoDB, and MS SQL",
      },
      {
        question: "How is data backed up and restored?",
        answer:
          "Databases can be backed up through scheduled jobs and restored from those backups as needed.",
      },
    ],
  },
  {
    title: "Software as a Service (SaaS)",
    items: [
      {
        question: "What SaaS applications are included or supported?",
        answer:
          "CMP provides SaaS solutions that include integrated development environments (IDEs) and preconfigured setups for Java, Python, and other popular programming languages. These environments are ready-to-use, allowing developers to start coding immediately without manual setup, streamlining the development process within the cloud.",
      },
      {
        question: "Is user data from SaaS apps isolated and secure?",
        answer:
          "Yes, data isolation and secure access are maintained using tenant-based isolation and secure storage.",
      },
    ],
  },
  {
    title: "CMP",
    items: [
      {
        question: 'What is the "Trust" feature in CMP?',
        answer:
          "Trust manages secure authentication, encryption, and certificate validation for integrations. It ensures data integrity and compliance during communications.",
      },
      {
        question: "Why is Feature Trust important?",
        answer:
          "It provides fine-grained security by controlling access to powerful or sensitive automation features. It ensures that only trusted sources or users can execute scripts, access protected APIs, or use specific integrations.",
      },
      {
        question: "What is Cypher in CMP?",
        answer:
          "Cypher is CMP built-in secure secrets manager. It allows users to store, retrieve, and manage credentials, API tokens, keys, and other secrets securely using role-based access controls (RBAC).",
      },
      {
        question: "What types of secrets can be stored in Cypher?",
        answer: (
          <div>
            <p className="mb-2">Common types include:</p>
            <ul className="list-disc list-inside space-y-1">
              <li>SSH keys</li>
              <li>API tokens</li>
              <li>Password</li>
              <li>Username & Password</li>
              <li>tfvars</li>
              <li>uuid</li>
              <li>Secret key</li>
            </ul>
          </div>
        ),
      },
      {
        question: "Can Cypher secrets be versioned or expired?",
        answer: (
          <div>
            <p className="mb-2">Yes. You can:</p>
            <ul className="list-disc list-inside space-y-1">
              <li>Define expiration times for secrets</li>
              <li>Enable rotating secrets (for dynamic secrets)</li>
              <li>
                View version history depending on the backend (especially with
                external vaults).
              </li>
            </ul>
          </div>
        ),
      },
    ],
  },
];

export const FaqPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState("");

  const filteredData = useMemo(() => {
    if (!searchTerm) return FAQ_DATA;
    const lowerTerm = searchTerm.toLowerCase();

    return FAQ_DATA.map((category) => {
      // Filter items matching the term
      const matchedItems = category.items.filter((item) =>
        item.question.toLowerCase().includes(lowerTerm),
      );

      // Return category only if it has matched items
      return {
        ...category,
        items: matchedItems,
      };
    }).filter((category) => category.items.length > 0);
  }, [searchTerm]);

  return (
    <div className="flex-1 space-y-6 p-8 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <h2 className="text-[14px] font-bold tracking-tight uppercase">
          Frequently Asked Questions
        </h2>
      </div>

      <div className="relative max-w-2xl mb-6">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search FAQs..."
          className="pl-9 bg-background"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {filteredData.map((category, idx) => (
          <Card key={idx} className="h-fit">
            <CardHeader className="bg-gray-50/50 dark:bg-gray-800/20 pb-4">
              <CardTitle className="text-lg">{category.title}</CardTitle>
            </CardHeader>
            <CardContent className="pt-4">
              <Accordion type="single" collapsible className="w-full">
                {category.items.map((item, itemIdx) => (
                  <AccordionItem key={itemIdx} value={`item-${idx}-${itemIdx}`}>
                    <AccordionTrigger className="text-left text-sm hover:no-underline">
                      {item.question}
                    </AccordionTrigger>
                    <AccordionContent className="text-muted-foreground">
                      {item.answer}
                    </AccordionContent>
                  </AccordionItem>
                ))}
              </Accordion>
            </CardContent>
          </Card>
        ))}

        {filteredData.length === 0 && (
          <div className="col-span-2 text-center py-12 text-muted-foreground">
            No FAQs found matching your search.
          </div>
        )}
      </div>
    </div>
  );
};
