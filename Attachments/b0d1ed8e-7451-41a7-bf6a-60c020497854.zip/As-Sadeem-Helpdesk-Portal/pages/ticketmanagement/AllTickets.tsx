import { ArrowUpDown, Loader2, Search, X } from "lucide-react";
import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../components/AuthProvider";
import {
  Badge,
  Button,
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  Input,
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
  Select,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../../components/ui-kit";
import apiService from "../../services/apiService";
import { Ticket } from "../../types";
import { buildAttachmentSrc } from "../../utils/attachment";

export const AllTickets: React.FC = () => {
  const navigate = useNavigate();
  const { username } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [sortConfig, setSortConfig] = useState<{
    key: keyof Ticket;
    direction: "asc" | "desc";
  } | null>(null);

  // Filters State
  const [statusFilter, setStatusFilter] = useState<string>("All");
  const [priorityFilter, setPriorityFilter] = useState<string>("All");
  const [categoryFilter, setCategoryFilter] = useState<string>("All");

  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 20;

  // Dynamic filter options based on loaded ticket data
  const statusOptions = useMemo(() => {
    const set = new Set<string>();
    tickets.forEach((t) => {
      if (t.status) set.add(t.status);
    });
    return Array.from(set).sort();
  }, [tickets]);

  const priorityOptions = useMemo(() => {
    const set = new Set<string>();
    tickets.forEach((t) => {
      if (t.priority) set.add(t.priority);
    });
    return Array.from(set).sort();
  }, [tickets]);

  const categoryOptions = useMemo(() => {
    const set = new Set<string>();
    tickets.forEach((t) => {
      if (t.category) set.add(t.category);
    });
    return Array.from(set).sort();
  }, [tickets]);

  useEffect(() => {
    const fetchTickets = async () => {
      if (!username) return;
      setIsLoading(true);
      try {
        // Fetch All tickets (TicketType null)
        const data = await apiService.getTickets(username, null);
        setTickets(data);
      } catch (error) {
        console.error("Failed to fetch all tickets", error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchTickets();
  }, [username]);

  const handleSort = (key: keyof Ticket) => {
    let direction: "asc" | "desc" = "asc";
    if (
      sortConfig &&
      sortConfig.key === key &&
      sortConfig.direction === "asc"
    ) {
      direction = "desc";
    }
    setSortConfig({ key, direction });
  };

  const filteredTickets = useMemo(() => {
    const parseDate = (value?: string) => {
      if (!value) return 0;
      const ts = Date.parse(value);
      return Number.isNaN(ts) ? 0 : ts;
    };

    const lowerTerm = searchTerm.toLowerCase();
    const normalize = (value?: string | null) => (value || "").toLowerCase();

    // 1. Apply All Filters
    let result = tickets.filter((ticket) => {
      // Global Search
      const matchesSearch =
        ticket.ticketId?.toString().toLowerCase().includes(lowerTerm) ||
        normalize(ticket.title).includes(lowerTerm) ||
        normalize(ticket.category).includes(lowerTerm) ||
        normalize(ticket.status).includes(lowerTerm) ||
        normalize(ticket.priority).includes(lowerTerm);

      // Specific Dropdown Filters
      const matchesStatus =
        statusFilter === "All" || ticket.status === statusFilter;
      const matchesPriority =
        priorityFilter === "All" || ticket.priority === priorityFilter;
      const matchesCategory =
        categoryFilter === "All" || ticket.category === categoryFilter;

      return (
        matchesSearch && matchesStatus && matchesPriority && matchesCategory
      );
    });

    // 2. Sort
    if (sortConfig) {
      result.sort((a, b) => {
        const aValue = a[sortConfig.key];
        const bValue = b[sortConfig.key];

        if (aValue === undefined || bValue === undefined) return 0;

        // If sorting by dates, compare by parsed time
        if (
          sortConfig.key === "ticketDate" ||
          sortConfig.key === "closingDate"
        ) {
          const aTime = parseDate(aValue as string);
          const bTime = parseDate(bValue as string);
          if (aTime < bTime) return sortConfig.direction === "asc" ? -1 : 1;
          if (aTime > bTime) return sortConfig.direction === "asc" ? 1 : -1;
          return 0;
        }

        if (aValue < (bValue as any)) {
          return sortConfig.direction === "asc" ? -1 : 1;
        }
        if (aValue > (bValue as any)) {
          return sortConfig.direction === "asc" ? 1 : -1;
        }
        return 0;
      });
    } else {
      // Default sort: newest tickets first by created date, then by ticketId
      result.sort((a, b) => {
        const aTime = parseDate(a.ticketDate);
        const bTime = parseDate(b.ticketDate);
        if (aTime !== bTime) return bTime - aTime;

        const aId = a.ticketId || "";
        const bId = b.ticketId || "";
        if (aId < bId) return 1;
        if (aId > bId) return -1;
        return 0;
      });
    }

    return result;
  }, [
    tickets,
    searchTerm,
    sortConfig,
    statusFilter,
    priorityFilter,
    categoryFilter,
  ]);

  // Reset to first page when any filter changes
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, statusFilter, priorityFilter, categoryFilter]);

  // Handle Filter Reset
  const clearFilters = () => {
    setStatusFilter("All");
    setPriorityFilter("All");
    setCategoryFilter("All");
    setSearchTerm("");
  };

  // Paginate Logic
  const totalPages = Math.ceil(filteredTickets.length / itemsPerPage);
  const paginatedTickets = filteredTickets.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage,
  );

  const getPageNumbers = () => {
    if (totalPages <= 7)
      return Array.from({ length: totalPages }, (_, i) => i + 1);

    if (currentPage <= 4) {
      return [1, 2, 3, 4, 5, "...", totalPages];
    }

    if (currentPage >= totalPages - 3) {
      return [
        1,
        "...",
        totalPages - 4,
        totalPages - 3,
        totalPages - 2,
        totalPages - 1,
        totalPages,
      ];
    }

    return [
      1,
      "...",
      currentPage - 1,
      currentPage,
      currentPage + 1,
      "...",
      totalPages,
    ];
  };

  const getPriorityColor = (priority: string) => {
    switch (priority.toLowerCase()) {
      case "high":
        return "destructive";
      case "medium":
        return "inform";
      case "low":
        return "warning";
      default:
        return "outline";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "open":
        return "secondary";
      case "resolved":
        return "default";
      case "hold":
        return "warning";
      case "failed":
        return "destructive";
      default:
        return "outline";
    }
  };

  const activeFiltersCount = [
    statusFilter !== "All",
    priorityFilter !== "All",
    categoryFilter !== "All",
    searchTerm !== "",
  ].filter(Boolean).length;

  return (
    <div className="flex-1 space-y-6 p-8 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <h2 className="text-[14px] font-bold tracking-tight uppercase">
          All Tickets
        </h2>
      </div>

      <Card>
        <CardHeader className="pb-4 space-y-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <CardTitle>Ticket History</CardTitle>

            {/* Toolbar: Filters & Search */}
            <div className="flex flex-col sm:flex-row gap-2 flex-1 md:justify-end">
              {/* Status Filter - options based on table data */}
              <div className="w-full sm:w-[140px]">
                <Select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                >
                  <option value="All">All Statuses</option>
                  {statusOptions.map((status) => (
                    <option key={status} value={status}>
                      {status}
                    </option>
                  ))}
                </Select>
              </div>

              {/* Priority Filter - options based on table data */}
              <div className="w-full sm:w-[140px]">
                <Select
                  value={priorityFilter}
                  onChange={(e) => setPriorityFilter(e.target.value)}
                >
                  <option value="All">All Priorities</option>
                  {priorityOptions.map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </Select>
              </div>

              {/* Category Filter - options based on table data */}
              <div className="w-full sm:w-[160px]">
                <Select
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                >
                  <option value="All">All Categories</option>
                  {categoryOptions.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </Select>
              </div>

              {/* Search Bar */}
              <div className="relative w-full sm:w-64">
                <Search className="absolute left-2 top-2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search..."
                  className="pl-8"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              {/* Reset Button (Only visible if filters active) */}
              {activeFiltersCount > 0 && (
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={clearFilters}
                  title="Clear Filters"
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
        </CardHeader>

        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead
                  onClick={() => handleSort("ticketId")}
                  className="cursor-pointer hover:bg-muted/80 w-[80px]"
                >
                  <div className="flex items-center space-x-1">
                    <span>ID</span>
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </TableHead>
                <TableHead
                  onClick={() => handleSort("title")}
                  className="cursor-pointer hover:bg-muted/80"
                >
                  <div className="flex items-center space-x-1">
                    <span>Title</span>
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </TableHead>
                <TableHead
                  onClick={() => handleSort("category")}
                  className="cursor-pointer hover:bg-muted/80"
                >
                  <div className="flex items-center space-x-1">
                    <span>Category</span>
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </TableHead>
                <TableHead
                  onClick={() => handleSort("status")}
                  className="cursor-pointer hover:bg-muted/80"
                >
                  <div className="flex items-center space-x-1">
                    <span>Status</span>
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </TableHead>
                <TableHead
                  onClick={() => handleSort("priority")}
                  className="cursor-pointer hover:bg-muted/80"
                >
                  <div className="flex items-center space-x-1">
                    <span>Priority</span>
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </TableHead>
                <TableHead
                  onClick={() => handleSort("ticketDate")}
                  className="cursor-pointer hover:bg-muted/80"
                >
                  <div className="flex items-center space-x-1">
                    <span>Created AT</span>
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </TableHead>
                <TableHead
                  onClick={() => handleSort("closingDate")}
                  className="cursor-pointer hover:bg-muted/80"
                >
                  <div className="flex items-center space-x-1">
                    <span>Resolved AT</span>
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </TableHead>
                <TableHead>Attachment</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={8} className="h-24 text-center">
                    <div className="flex justify-center items-center">
                      <Loader2 className="h-6 w-6 animate-spin text-primary" />
                    </div>
                  </TableCell>
                </TableRow>
              ) : paginatedTickets.length > 0 ? (
                paginatedTickets.map((ticket) => (
                  <TableRow
                    key={ticket.ticketId || ticket.oid}
                    className="cursor-pointer hover:bg-muted/50"
                    onClick={() =>
                      navigate(`/tickets/${ticket.ticketId}`, {
                        state: { ticket },
                      })
                    }
                  >
                    <TableCell className="font-medium whitespace-nowrap">
                      #{ticket.ticketId || ticket.oid}
                    </TableCell>
                    <TableCell className="font-medium">
                      {ticket.title}
                    </TableCell>
                    <TableCell>{ticket.category}</TableCell>
                    <TableCell>
                      <Badge
                        variant={getStatusColor(ticket.status) as any}
                        //  className={ticket.status === 'Resolved' ? 'bg-green-600 hover:bg-green-700 text-white' : ''}
                        className={
                          ticket.status === "Resolved" ? "default" : ""
                        }
                      >
                        {ticket.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant={getPriorityColor(ticket.priority) as any}>
                        {ticket.priority}
                      </Badge>
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      {ticket.ticketDate}
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      {ticket.closingDate || "-"}
                    </TableCell>
                    <TableCell>
                      {(() => {
                        const attachmentSrc = buildAttachmentSrc(
                          ticket.attachment,
                          ticket.attachmentName,
                        );
                        return attachmentSrc ? (
                          <div className="h-6 w-6 overflow-hidden rounded-md border bg-muted">
                            <img
                              src={attachmentSrc}
                              alt="Attach"
                              className="h-full w-full object-cover"
                            />
                          </div>
                        ) : (
                          <span className="text-muted-foreground">
                            No Attachement
                          </span>
                        );
                      })()}
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell
                    colSpan={8}
                    className="h-24 text-center text-muted-foreground"
                  >
                    No tickets found matching your filters.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>

          {totalPages > 1 && (
            <div className="py-4 border-t">
              <Pagination>
                <PaginationContent>
                  <PaginationItem>
                    <PaginationPrevious
                      onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                      className={
                        currentPage === 1
                          ? "pointer-events-none opacity-50"
                          : "cursor-pointer"
                      }
                    />
                  </PaginationItem>

                  {getPageNumbers().map((page, index) => (
                    <PaginationItem key={index}>
                      {page === "..." ? (
                        <PaginationEllipsis />
                      ) : (
                        <PaginationLink
                          onClick={() => setCurrentPage(page as number)}
                          isActive={currentPage === page}
                          className="cursor-pointer"
                        >
                          {page}
                        </PaginationLink>
                      )}
                    </PaginationItem>
                  ))}

                  <PaginationItem>
                    <PaginationNext
                      onClick={() =>
                        setCurrentPage((p) => Math.min(totalPages, p + 1))
                      }
                      className={
                        currentPage === totalPages
                          ? "pointer-events-none opacity-50"
                          : "cursor-pointer"
                      }
                    />
                  </PaginationItem>
                </PaginationContent>
              </Pagination>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
