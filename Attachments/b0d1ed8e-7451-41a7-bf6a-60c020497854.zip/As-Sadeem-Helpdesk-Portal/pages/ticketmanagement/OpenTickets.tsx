import { ArrowUpDown, Loader2, Plus, Search } from "lucide-react";
import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../components/AuthProvider";
import { CreateTicketModal } from "../../components/CreateTicketModal";
import {
  Badge,
  Button,
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  Input,
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../../components/ui-kit";
import apiService from "../../services/apiService";
import { Ticket } from "../../types";
import { buildAttachmentSrc } from "../../utils/attachment";

export const OpenTickets: React.FC = () => {
  const navigate = useNavigate();
  const { username } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [sortConfig, setSortConfig] = useState<{
    key: keyof Ticket;
    direction: "asc" | "desc";
  } | null>(null);

  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 20;

  const fetchTickets = useCallback(async () => {
    if (!username) return;
    setIsLoading(true);
    try {
      const data = await apiService.getTickets(username, "Open");
      setTickets(data);
    } catch (error) {
      console.error("Failed to fetch open tickets", error);
    } finally {
      setIsLoading(false);
    }
  }, [username]);

  useEffect(() => {
    fetchTickets();
  }, [fetchTickets]);

  const handleSort = (key: keyof Ticket) => {
    let direction: "asc" | "desc" = "asc";
    if (
      sortConfig &&
      sortConfig.key === key &&
      sortConfig.direction === "asc"
    ) {
      direction = "desc";
    }
    setSortConfig({ key, direction });
  };

  const filteredTickets = useMemo(() => {
    const parseDate = (value?: string) => {
      if (!value) return 0;
      const ts = Date.parse(value);
      return Number.isNaN(ts) ? 0 : ts;
    };

    const lowerTerm = searchTerm.toLowerCase();
    const normalize = (value?: string | null) => (value || "").toLowerCase();

    // 1. Filter
    let result = tickets.filter(
      (ticket) =>
        ticket.ticketId?.toString().toLowerCase().includes(lowerTerm) ||
        normalize(ticket.subject).includes(lowerTerm) ||
        normalize(ticket.status).includes(lowerTerm) ||
        normalize(ticket.priority).includes(lowerTerm),
    );

    // 2. Sort
    if (sortConfig) {
      result.sort((a, b) => {
        const aValue = a[sortConfig.key];
        const bValue = b[sortConfig.key];

        if (aValue === undefined || bValue === undefined) return 0;

        if (sortConfig.key === "ticketDate") {
          const aTime = parseDate(aValue as string);
          const bTime = parseDate(bValue as string);
          if (aTime < bTime) return sortConfig.direction === "asc" ? -1 : 1;
          if (aTime > bTime) return sortConfig.direction === "asc" ? 1 : -1;
          return 0;
        }

        if (aValue < (bValue as any)) {
          return sortConfig.direction === "asc" ? -1 : 1;
        }
        if (aValue > (bValue as any)) {
          return sortConfig.direction === "asc" ? 1 : -1;
        }
        return 0;
      });
    } else {
      // Default: newest tickets first
      result.sort((a, b) => {
        const aTime = parseDate(a.ticketDate);
        const bTime = parseDate(b.ticketDate);
        if (aTime !== bTime) return bTime - aTime;

        const aId = a.ticketId || "";
        const bId = b.ticketId || "";
        if (aId < bId) return 1;
        if (aId > bId) return -1;
        return 0;
      });
    }

    return result;
  }, [tickets, searchTerm, sortConfig]);

  // Reset to first page when search changes
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm]);

  // Paginate Logic
  const totalPages = Math.ceil(filteredTickets.length / itemsPerPage);
  const paginatedTickets = filteredTickets.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage,
  );

  const getPageNumbers = () => {
    if (totalPages <= 7)
      return Array.from({ length: totalPages }, (_, i) => i + 1);

    if (currentPage <= 4) {
      return [1, 2, 3, 4, 5, "...", totalPages];
    }

    if (currentPage >= totalPages - 3) {
      return [
        1,
        "...",
        totalPages - 4,
        totalPages - 3,
        totalPages - 2,
        totalPages - 1,
        totalPages,
      ];
    }

    return [
      1,
      "...",
      currentPage - 1,
      currentPage,
      currentPage + 1,
      "...",
      totalPages,
    ];
  };

  const handleCreateTicket = async () => {
    await fetchTickets();
    setIsModalOpen(false);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority.toLowerCase()) {
      case "high":
        return "destructive";
      case "medium":
        return "inform";
      case "low":
        return "warning";
      default:
        return "outline";
    }
  };

  return (
    <div className="flex-1 space-y-6 p-8 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <h2 className="text-[14px] font-bold tracking-tight uppercase">
          Open Tickets
        </h2>
        <Button onClick={() => setIsModalOpen(true)}>
          <Plus className="mr-2 h-4 w-4" /> Create New Ticket
        </Button>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle>Ticket List</CardTitle>
            <div className="relative w-64">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search tickets..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead
                  onClick={() => handleSort("ticketId")}
                  className="cursor-pointer hover:bg-muted/80 w-[80px]"
                >
                  <div className="flex items-center space-x-1">
                    <span>ID</span>
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </TableHead>
                <TableHead
                  onClick={() => handleSort("title")}
                  className="cursor-pointer hover:bg-muted/80"
                >
                  <div className="flex items-center space-x-1">
                    <span>Title</span>
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </TableHead>
                <TableHead
                  onClick={() => handleSort("category")}
                  className="cursor-pointer hover:bg-muted/80"
                >
                  <div className="flex items-center space-x-1">
                    <span>Category</span>
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </TableHead>
                <TableHead
                  onClick={() => handleSort("status")}
                  className="cursor-pointer hover:bg-muted/80"
                >
                  <div className="flex items-center space-x-1">
                    <span>Status</span>
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </TableHead>
                <TableHead
                  onClick={() => handleSort("priority")}
                  className="cursor-pointer hover:bg-muted/80"
                >
                  <div className="flex items-center space-x-1">
                    <span>Priority</span>
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </TableHead>
                <TableHead
                  onClick={() => handleSort("ticketDate")}
                  className="cursor-pointer hover:bg-muted/80"
                >
                  <div className="flex items-center space-x-1">
                    <span>Created AT</span>
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </TableHead>
                <TableHead>Attachment</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={7} className="h-24 text-center">
                    <div className="flex justify-center items-center">
                      <Loader2 className="h-6 w-6 animate-spin text-primary" />
                    </div>
                  </TableCell>
                </TableRow>
              ) : paginatedTickets.length > 0 ? (
                paginatedTickets.map((ticket) => (
                  <TableRow
                    key={ticket.ticketId || ticket.oid}
                    className="cursor-pointer hover:bg-muted/50"
                    onClick={() =>
                      navigate(`/tickets/${ticket.ticketId}`, {
                        state: { ticket },
                      })
                    }
                  >
                    <TableCell className="font-medium whitespace-nowrap">
                      #{ticket.ticketId || ticket.oid}
                    </TableCell>
                    <TableCell className="font-medium">
                      {ticket.title}
                    </TableCell>
                    <TableCell>{ticket.category}</TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className="bg-green-50 text-green-700 border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-800"
                      >
                        {ticket.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant={getPriorityColor(ticket.priority) as any}>
                        {ticket.priority}
                      </Badge>
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      {ticket.ticketDate}
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      {/* {ticket.attachmentName? ticket.attachmentName : 'None'} */}
                      {/* {ticket.attachment ? (
                        <div className="h-10 w-10 overflow-hidden rounded-md border bg-muted">
                           <img src={ticket.attachment} alt="Attach" className="h-full w-full object-cover" />
                        </div>
                      ) : (
                        <span className="text-muted-foreground text-xs">None</span>
                      )}  */}
                      {(() => {
                        const attachmentSrc = buildAttachmentSrc(
                          ticket.attachment,
                          ticket.attachmentName,
                        );
                        return attachmentSrc ? (
                          <div className="h-6 w-6 overflow-hidden rounded-md border bg-muted">
                            <img
                              src={attachmentSrc}
                              alt="Attach"
                              className="h-full w-full object-cover"
                            />
                          </div>
                        ) : (
                          <span className="text-muted-foreground">
                            No Attachement
                          </span>
                        );
                      })()}
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={7} className="h-24 text-center">
                    No open tickets found.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>

          {totalPages > 1 && (
            <div className="mt-4">
              <Pagination>
                <PaginationContent>
                  <PaginationItem>
                    <PaginationPrevious
                      onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                      className={
                        currentPage === 1
                          ? "pointer-events-none opacity-50"
                          : "cursor-pointer"
                      }
                    />
                  </PaginationItem>

                  {getPageNumbers().map((page, index) => (
                    <PaginationItem key={index}>
                      {page === "..." ? (
                        <PaginationEllipsis />
                      ) : (
                        <PaginationLink
                          onClick={() => setCurrentPage(page as number)}
                          isActive={currentPage === page}
                          className="cursor-pointer"
                        >
                          {page}
                        </PaginationLink>
                      )}
                    </PaginationItem>
                  ))}

                  <PaginationItem>
                    <PaginationNext
                      onClick={() =>
                        setCurrentPage((p) => Math.min(totalPages, p + 1))
                      }
                      className={
                        currentPage === totalPages
                          ? "pointer-events-none opacity-50"
                          : "cursor-pointer"
                      }
                    />
                  </PaginationItem>
                </PaginationContent>
              </Pagination>
            </div>
          )}
        </CardContent>
      </Card>

      <CreateTicketModal
        open={isModalOpen}
        onOpenChange={setIsModalOpen}
        onSubmit={handleCreateTicket}
      />
    </div>
  );
};
