import {
  ArrowLeft,
  ArrowUpDown,
  CheckCircle,
  Download,
  Loader2,
  Paperclip,
  Send,
  Upload,
  X,
} from "lucide-react";
import React, { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { useAuth } from "../../components/AuthProvider";
import {
  Badge,
  Button,
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  Dialog,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  Label,
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
  Textarea,
} from "../../components/ui-kit";
import apiService from "../../services/apiService";
import { Reply, Ticket } from "../../types";
import { buildAttachmentSrc } from "../../utils/attachment";

// Helper component for text truncation with modal
const ReadMoreText = ({
  text,
  limit = 150,
  title = "Details",
}: {
  text: string;
  limit?: number;
  title?: string;
}) => {
  const [showModal, setShowModal] = useState(false);

  if (!text) return null;

  const shouldTruncate = text.length > limit;

  return (
    <>
      <div className={shouldTruncate ? "relative" : ""}>
        <span className={shouldTruncate ? "line-clamp-2" : ""}>{text}</span>
        {shouldTruncate && (
          <span
            className="text-primary text-sm font-bold cursor-pointer hover:underline mt-1 inline-block"
            onClick={() => setShowModal(true)}
          >
            Read more...
          </span>
        )}
      </div>

      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>
        <div className="py-4 whitespace-pre-wrap max-h-[60vh] overflow-y-auto text-sm">
          {text}
        </div>
        <DialogFooter>
          <Button onClick={() => setShowModal(false)}>Close</Button>
        </DialogFooter>
      </Dialog>
    </>
  );
};

export const TicketDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const { username } = useAuth();
  const passedTicket = (location.state as { ticket?: Ticket })?.ticket;
  const [ticket, setTicket] = useState<Ticket | null>(null);
  const [replies, setReplies] = useState<Reply[]>([]);
  const [replyText, setReplyText] = useState("");
  const [replyFile, setReplyFile] = useState<File | null>(null);
  const [replyPreviewUrl, setReplyPreviewUrl] = useState<string | null>(null);
  const [fileError, setFileError] = useState<string>("");
  const [isSendingReply, setIsSendingReply] = useState<boolean>(false);
  const [replyError, setReplyError] = useState<string | null>(null);
  const [isLoadingTicket, setIsLoadingTicket] = useState<boolean>(true);
  const [isResolvingTicket, setIsResolvingTicket] = useState<boolean>(false);

  // Pagination & Sorting State for Replies
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 3; // Smaller page size for conversation history usually
  const [sortConfig, setSortConfig] = useState<{
    key: keyof Reply;
    direction: "asc" | "desc";
  } | null>(null);

  useEffect(() => {
    const loadTicket = async () => {
      if (passedTicket) {
        setTicket(passedTicket);
        setIsLoadingTicket(false);
        return;
      }

      if (!username || !id) {
        setIsLoadingTicket(false);
        return;
      }

      try {
        const allTickets = await apiService.getTickets(username, null);
        const foundTicket = allTickets.find(
          (t) => t.ticketId === id || t.oid === id,
        );

        if (foundTicket) {
          setTicket(foundTicket);
        }
      } catch (error) {
        console.error("Failed to load ticket details", error);
      } finally {
        setIsLoadingTicket(false);
      }
    };

    loadTicket();
  }, [id, passedTicket, username]);

  useEffect(() => {
    const loadDiscussions = async () => {
      if (!ticket?.oid) return;
      try {
        const list = await apiService.getDiscussions(ticket.oid);
        setReplies(list);
      } catch (error) {
        console.error("Failed to load discussions", error);
      }
    };

    loadDiscussions();
  }, [ticket?.oid]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    setFileError("");
    if (file) {
      const validTypes = ["image/jpeg", "image/png"];
      if (!validTypes.includes(file.type)) {
        setFileError(
          "Only JPEG or PNG image is allowed. Please upload image below 2MB.",
        );
        return;
      }
      const maxSize = 2 * 1024 * 1024; // 2MB in bytes
      if (file.size > maxSize) {
        setFileError("Image size should not be greater than 2MB.");
        return;
      }
      const url = URL.createObjectURL(file);
      setReplyFile(file);
      setReplyPreviewUrl(url);
    }
  };

  const handleSendReply = async () => {
    if (!ticket || (!replyText && !replyFile)) return;
    setReplyError(null);
    setIsSendingReply(true);

    // Generate date string YYYY-MM-DD HH:mm
    const now = new Date();
    const dateStr = now.toISOString().replace("T", " ").substring(0, 16);

    try {
      const formData = new FormData();
      formData.append("CaseID", ticket.oid);
      formData.append("ContactID", sessionStorage.getItem("contactOid") || "");
      formData.append("Replay", replyText || "");
      if (replyFile) {
        formData.append("Attachment", replyFile, replyFile.name);
      }

      await apiService.createDiscussionReply(formData);

      // Reload discussions from backend so they persist across reloads
      const updated = await apiService.getDiscussions(ticket.oid);
      setReplies(updated);
      setReplyText("");
      setReplyFile(null);
      setReplyPreviewUrl(null);
    } catch (error) {
      console.error("Failed to send reply", error);
      setReplyError("Failed to send reply. Please try again.");
    } finally {
      setIsSendingReply(false);
    }
  };

  // --- Sorting & Pagination Logic for Replies ---
  const handleSort = (key: keyof Reply) => {
    let direction: "asc" | "desc" = "asc";
    if (
      sortConfig &&
      sortConfig.key === key &&
      sortConfig.direction === "asc"
    ) {
      direction = "desc";
    }
    setSortConfig({ key, direction });
  };

  const processedReplies = useMemo(() => {
    let result = [...replies];

    if (sortConfig) {
      result.sort((a, b) => {
        const aValue = a[sortConfig.key];
        const bValue = b[sortConfig.key];

        if (aValue === undefined || bValue === undefined) return 0;
        if (aValue < bValue) return sortConfig.direction === "asc" ? -1 : 1;
        if (aValue > bValue) return sortConfig.direction === "asc" ? 1 : -1;
        return 0;
      });
    }
    return result;
  }, [replies, sortConfig]);

  const totalPages = Math.ceil(processedReplies.length / itemsPerPage);
  const paginatedReplies = processedReplies.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage,
  );

  const getPageNumbers = () => {
    if (totalPages <= 7)
      return Array.from({ length: totalPages }, (_, i) => i + 1);

    if (currentPage <= 4) {
      return [1, 2, 3, 4, 5, "...", totalPages];
    }

    if (currentPage >= totalPages - 3) {
      return [
        1,
        "...",
        totalPages - 4,
        totalPages - 3,
        totalPages - 2,
        totalPages - 1,
        totalPages,
      ];
    }

    return [
      1,
      "...",
      currentPage - 1,
      currentPage,
      currentPage + 1,
      "...",
      totalPages,
    ];
  };

  const getPriorityColor = (priority: string) => {
    switch (priority.toLowerCase()) {
      case "high":
        return "destructive";
      case "medium":
        return "inform";
      case "low":
        return "warning";
      default:
        return "outline";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "open":
        return "default";
      case "resolved":
        return "default";
      case "hold":
        return "warning";
      case "failed":
        return "destructive";
      default:
        return "outline";
    }
  };

  if (isLoadingTicket) {
    return <div className="p-8">Loading ticket...</div>;
  }

  if (!ticket) {
    return <div className="p-8">Ticket not found</div>;
  }

  const ticketAttachmentSrc = buildAttachmentSrc(
    ticket.attachment,
    ticket.attachmentName,
  );

  const downloadImage = async (
    src: string | null | undefined,
    fileName: string | null | undefined,
  ) => {
    if (!src) return;

    try {
      // Fetch the image data
      const response = await fetch(src);
      const blob = await response.blob();

      // Create a blob URL
      const blobUrl = window.URL.createObjectURL(blob);

      // Create a temporary anchor element to trigger download
      const link = document.createElement("a");
      link.href = blobUrl;
      link.download = fileName || "attachment";
      document.body.appendChild(link);
      link.click();

      // Clean up
      document.body.removeChild(link);
      window.URL.revokeObjectURL(blobUrl);
    } catch (error) {
      console.error("Failed to download image", error);
      // Fallback: try direct download
      const link = document.createElement("a");
      link.href = src;
      link.download = fileName || "attachment";
      link.target = "_blank";
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const handleResolveTicket = async () => {
    if (!ticket) return;
    setIsResolvingTicket(true);
    try {
      const updated = await apiService.resolveTicket(ticket.oid);
      setTicket(updated);
      navigate("/tickets/closed");
    } catch (error) {
      console.error("Failed to resolve ticket", error);
    } finally {
      setIsResolvingTicket(false);
    }
  };

  return (
    <div className="flex-1 space-y-6 p-8 pt-6">
      {/* Header Section: Title Left, Resolve Button Right */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-4">
          <Button variant="outline" size="icon" onClick={() => navigate(-1)}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h2 className="text-[14px] font-bold tracking-tight uppercase">
            Ticket #{ticket.ticketId} - Details
          </h2>
        </div>
        {ticket.status.toLowerCase() !== "resolved" && (
          <Button onClick={handleResolveTicket} disabled={isResolvingTicket}>
            {isResolvingTicket ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <CheckCircle className="mr-2 h-4 w-4" />
            )}
            {isResolvingTicket ? "Resolving..." : "Resolve Ticket"}
          </Button>
        )}
      </div>

      {/* Main Grid: Two Columns, Equal Height */}
      <div className="grid gap-6 md:grid-cols-2 items-stretch">
        {/* Left Column: Description + Reply Form */}
        <div className="flex flex-col gap-6 h-full order-last md:order-first">
          {/* Description Card */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Description</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-muted-foreground whitespace-pre-wrap">
                <ReadMoreText
                  text={ticket.description || "No description provided."}
                  limit={150}
                  title="Ticket Description"
                />
              </div>
            </CardContent>
          </Card>

          {/* Add Reply Card: flex-1 to fill vertical space */}
          <Card className="flex-1 flex flex-col">
            <CardHeader className="pb-3">
              <CardTitle>Add Reply</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 flex-1 flex flex-col">
              <div className="space-y-2">
                <Label>Message</Label>
                <Textarea
                  placeholder="Type your reply here..."
                  className="min-h-[150px]"
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  maxLength={1500}
                />
                <p className="text-xs text-muted-foreground">
                  Note: Max of 1500 characters are allowed only.
                </p>
              </div>

              <div className="space-y-2">
                <Label>Attachment</Label>
                {!replyPreviewUrl ? (
                  <div className="flex flex-col gap-1">
                    <div className="flex items-center gap-2">
                      <label
                        htmlFor="reply-file"
                        className="cursor-pointer inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none ring-offset-background border border-input hover:bg-accent hover:text-accent-foreground h-9 px-4 py-2 w-full"
                      >
                        <Upload className="mr-2 h-4 w-4" /> Upload Image
                      </label>
                      <input
                        id="reply-file"
                        type="file"
                        className="hidden"
                        accept="image/jpeg, image/png"
                        onChange={handleFileChange}
                      />
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Note: Only JPEG or PNG image is allowed. Please upload
                      image below 2MB.
                    </p>
                    {fileError && (
                      <p className="text-xs text-destructive font-medium">
                        {fileError}
                      </p>
                    )}
                  </div>
                ) : (
                  <div className="flex items-center justify-between p-2 border rounded-md">
                    <div className="flex items-center gap-2 truncate">
                      <Paperclip className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">Image Attached</span>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setReplyFile(null);
                        setReplyPreviewUrl(null);
                      }}
                      className="h-8 w-8 p-0 text-destructive"
                    >
                      <span className="sr-only">Remove</span>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </div>
              {ticket.status.toLowerCase() !== "resolved" && (
                <>
                  <div className="mt-auto pt-4">
                    <Button
                      className="w-full"
                      onClick={handleSendReply}
                      disabled={isSendingReply}
                    >
                      <Send className="mr-2 h-4 w-4" />{" "}
                      {isSendingReply ? "Sending..." : "Reply"}
                    </Button>
                    {replyError && (
                      <p className="mt-2 text-xs text-destructive text-center">
                        {replyError}
                      </p>
                    )}
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Right Column: Ticket Information */}
        <div className="flex flex-col h-full">
          <Card className="h-full">
            <CardHeader className="pb-3">
              <CardTitle>Ticket Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <Label className="text-muted-foreground">Title</Label>
                  <div className="font-medium mt-1">{ticket.title}</div>
                </div>
                <div>
                  <Label className="text-muted-foreground">Category</Label>
                  <div className="font-medium mt-1">
                    {ticket.category}{" "}
                    {/* {ticket.subCategory ? `/ ${ticket.subCategory}` : ""} */}
                  </div>
                </div>
                <div>
                  <Label className="text-muted-foreground">Sub-Category</Label>
                  <div className="font-medium mt-1">
                    {ticket.subCategory ? `${ticket.subCategory}` : ""}
                  </div>
                </div>
                <div>
                  <Label className="text-muted-foreground">Status</Label>
                  <div className="mt-1">
                    <Badge variant={getStatusColor(ticket.status) as any}>
                      {ticket.status}
                    </Badge>
                  </div>
                </div>
                <div>
                  <Label className="text-muted-foreground">Priority</Label>
                  <div className="mt-1">
                    <Badge variant={getPriorityColor(ticket.priority) as any}>
                      {ticket.priority}
                    </Badge>
                  </div>
                </div>
                <div>
                  <Label className="text-muted-foreground">Created at</Label>
                  <div className="font-medium mt-1">{ticket.ticketDate}</div>
                </div>
                <div>
                  <Label className="text-muted-foreground">Resolved at</Label>
                  <div className="font-medium mt-1">
                    {ticket.closingDate || "NA"}
                  </div>
                </div>
              </div>

              <div>
                <Label className="text-muted-foreground">Attachment</Label>
                <div className="mt-2">
                  {ticketAttachmentSrc ? (
                    <Button
                      variant="outline"
                      onClick={() =>
                        downloadImage(
                          ticketAttachmentSrc,
                          ticket.attachmentName || undefined,
                        )
                      }
                      className="flex items-center gap-2"
                    >
                      <Download className="h-4 w-4" />
                      {ticket.attachmentName || "Download Attachment"}
                    </Button>
                  ) : (
                    <span className="text-sm text-muted-foreground">
                      No attachment
                    </span>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Replies Table */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Conversation History</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead
                  onClick={() => handleSort("date")}
                  className="cursor-pointer hover:bg-muted/80 w-[150px]"
                >
                  <div className="flex items-center space-x-1">
                    <span>Time</span>
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </TableHead>
                <TableHead
                  onClick={() => handleSort("message")}
                  className="cursor-pointer hover:bg-muted/80"
                >
                  <div className="flex items-center space-x-1">
                    <span>Comment</span>
                    <ArrowUpDown className="h-3 w-3" />
                  </div>
                </TableHead>
                <TableHead className="w-[160px]">Attachment Name</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginatedReplies.length > 0 ? (
                paginatedReplies.map((reply) => (
                  <TableRow key={reply.id}>
                    <TableCell>{reply.date}</TableCell>
                    <TableCell className="min-w-[200px]">
                      <div className="text-xs font-semibold mb-1">
                        {/* If PostedBy exists, always show CRM-Admin label.
                            Otherwise fall back to sender, and finally CRM-Admin. */}
                        {reply.postedBy
                          ? reply.postedBy
                          : reply.sender
                            ? reply.sender
                            : " You "}
                      </div>
                      <ReadMoreText
                        text={reply.message}
                        limit={100}
                        title="Message Details"
                      />
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      {(() => {
                        const attachmentSrc = buildAttachmentSrc(
                          reply.attachment,
                          reply.attachmentName,
                        );
                        return attachmentSrc ? (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() =>
                              downloadImage(
                                attachmentSrc,
                                reply.attachmentName || undefined,
                              )
                            }
                            className="flex items-center gap-1 h-8"
                          >
                            <Download className="h-3 w-3" />
                            <span className="text-xs">Download</span>
                          </Button>
                        ) : (
                          <span className="text-muted-foreground text-xs">
                            No attachment
                          </span>
                        );
                      })()}
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell
                    colSpan={3}
                    className="h-24 text-center text-muted-foreground"
                  >
                    No replies yet.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>

          {totalPages > 1 && (
            <div className="mt-4">
              <Pagination>
                <PaginationContent>
                  <PaginationItem>
                    <PaginationPrevious
                      onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                      className={
                        currentPage === 1
                          ? "pointer-events-none opacity-50"
                          : "cursor-pointer"
                      }
                    />
                  </PaginationItem>

                  {getPageNumbers().map((page, index) => (
                    <PaginationItem key={index}>
                      {page === "..." ? (
                        <PaginationEllipsis />
                      ) : (
                        <PaginationLink
                          onClick={() => setCurrentPage(page as number)}
                          isActive={currentPage === page}
                          className="cursor-pointer"
                        >
                          {page}
                        </PaginationLink>
                      )}
                    </PaginationItem>
                  ))}

                  <PaginationItem>
                    <PaginationNext
                      onClick={() =>
                        setCurrentPage((p) => Math.min(totalPages, p + 1))
                      }
                      className={
                        currentPage === totalPages
                          ? "pointer-events-none opacity-50"
                          : "cursor-pointer"
                      }
                    />
                  </PaginationItem>
                </PaginationContent>
              </Pagination>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
