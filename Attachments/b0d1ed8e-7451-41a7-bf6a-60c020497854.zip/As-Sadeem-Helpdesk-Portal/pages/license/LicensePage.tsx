import React from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../../components/ui-kit";

export const LicensePage: React.FC = () => {
  return (
    <div className="flex-1 space-y-6 p-8 pt-6">
      <div className="flex items-center justify-between space-y-2">
        <h2 className="text-[14px] font-bold tracking-tight uppercase">
          License Information
        </h2>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Helpdesk License</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p>
            <strong>Version:</strong> 1.0.0
          </p>
          <p>
            <strong>Licensed to:</strong> Admin User
          </p>
          <p>
            This software is proprietary and confidential. Unauthorized copying
            of this file, via any medium is strictly prohibited.
          </p>
          <p className="text-sm text-muted-foreground mt-4">
            Copyright © 2025 Nexus Corp. All rights reserved.
          </p>
        </CardContent>
      </Card>
    </div>
  );
};
