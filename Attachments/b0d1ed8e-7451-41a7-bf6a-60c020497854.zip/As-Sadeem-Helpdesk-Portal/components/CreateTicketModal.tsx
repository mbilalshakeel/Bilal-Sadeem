import React, { useState, useEffect } from "react";
import { Upload, Trash2, Loader2 } from "lucide-react";
import { z } from "zod";
import {
  Button,
  Input,
  Dialog,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  Label,
  Select,
  Textarea,
} from "./ui-kit";
import { PRIORITIES } from "../constants";
import { Ticket, TicketCategory } from "../types";
import apiService from "../services/apiService";

interface CreateTicketModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit?: () => void | Promise<void>;
}

// Zod Schema
const ticketSchema = z.object({
  title: z.string().min(1, "Title is required"),
  subject: z.string().min(1, "Category is required"),
  subCategory: z.string().min(1, "Sub-Category is required"),
  priority: z.string().min(1, "Priority is required"),
  description: z
    .string()
    .min(1, "Description is required")
    .max(1500, "Max of 1500 characters are allowed only."),
  attachment: z.string().optional(),
});

export const CreateTicketModal: React.FC<CreateTicketModalProps> = ({
  open,
  onOpenChange,
  onSubmit,
}) => {
  // const { username } = useAuth();
  const [newTicket, setNewTicket] = useState<Partial<Ticket>>({
    title: "",
    subject: "",
    subCategory: "",
    priority: "",
    description: "",
    attachment: "",
  });
  const [categoryOid, setCategoryOid] = useState<string>("");
  const [subCategoryOid, setSubCategoryOid] = useState<string>("");

  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [attachmentName, setAttachmentName] = useState<string>("");
  const [attachmentFile, setAttachmentFile] = useState<File | null>(null);
  const [categories, setCategories] = useState<TicketCategory[]>([]);
  const [categoriesError, setCategoriesError] = useState<string | null>(null);
  const [isLoadingCategories, setIsLoadingCategories] =
    useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    const fetchCategories = async () => {
      setIsLoadingCategories(true);
      setCategoriesError(null);
      try {
        const data = await apiService.getCategories();
        if (!Array.isArray(data) || data.length === 0) {
          setCategories([]);
          setCategoriesError("No categories available.");
          return;
        }
        setCategories(data);
      } catch (error) {
        console.error("Failed to load categories", error);
        setCategoriesError("Unable to load categories. Please try again.");
      } finally {
        setIsLoadingCategories(false);
      }
    };

    fetchCategories();
  }, []);

  useEffect(() => {
    if (!toastMessage) return;
    const timer = setTimeout(() => setToastMessage(null), 3000);
    return () => clearTimeout(timer);
  }, [toastMessage]);

  const handleInputChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >,
  ) => {
    const { name, value } = e.target;

    setNewTicket((prev) => ({
      ...prev,
      [name]: value,
    }));
    // Clear error for this field
    if (errors[name]) {
      setErrors((prev) => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  const handleCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedOid = e.target.value;
    const selectedCategory = categories.find((cat) => cat.Oid === selectedOid);

    setCategoryOid(selectedOid);
    setSubCategoryOid("");
    setNewTicket((prev) => ({
      ...prev,
      subject: selectedCategory?.Title || "",
      subCategory: "",
    }));

    setErrors((prev) => {
      const newErrors = { ...prev };
      delete newErrors.subject;
      delete newErrors.subCategory;
      return newErrors;
    });
  };

  const handleSubCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const selectedOid = e.target.value;
    const selectedSubCategory = categories
      .find((cat) => cat.Oid === categoryOid)
      ?.SubCategories.find((sub) => sub.Oid === selectedOid);

    setSubCategoryOid(selectedOid);
    setNewTicket((prev) => ({
      ...prev,
      subCategory: selectedSubCategory?.Title || "",
    }));

    if (errors.subCategory) {
      setErrors((prev) => {
        const newErrors = { ...prev };
        delete newErrors.subCategory;
        return newErrors;
      });
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type
      const validTypes = ["image/jpeg", "image/png"];
      if (!validTypes.includes(file.type)) {
        setErrors((prev) => ({
          ...prev,
          attachment:
            "Only JPEG or PNG image is allowed. Please upload image below 2MB.",
        }));
        return;
      }
      const maxSize = 2 * 1024 * 1024; // 2MB in bytes
      if (file.size > maxSize) {
        setErrors((prev) => ({
          ...prev,
          attachment: "Image size should not be greater than 2MB.",
        }));
        return;
      }
      const objectUrl = URL.createObjectURL(file);
      setPreviewUrl(objectUrl);
      setAttachmentName(file.name);
      setAttachmentFile(file);
      setNewTicket((prev) => ({
        ...prev,
        attachment: objectUrl,
        attachmentName: file.name,
      }));

      if (errors.attachment) {
        setErrors((prev) => {
          const newErrors = { ...prev };
          delete newErrors.attachment;
          return newErrors;
        });
      }
    }
  };

  const handleDeleteAttachment = () => {
    setPreviewUrl(null);
    setAttachmentName("");
    setAttachmentFile(null);
    setNewTicket((prev) => ({ ...prev, attachment: "", attachmentName: "" }));
  };
  const accountOid = sessionStorage.getItem("accountOid") || "";
  const contactOid = sessionStorage.getItem("contactOid") || "";
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError(null);

    // Validate with Zod
    try {
      ticketSchema.parse(newTicket);
      setErrors({}); // Clear errors if validation passes
    } catch (error) {
      if (error instanceof z.ZodError) {
        const fieldErrors: Record<string, string> = {};
        error.issues.forEach((err) => {
          if (err.path[0]) {
            fieldErrors[err.path[0] as string] = err.message;
          }
        });
        setErrors(fieldErrors);
      }
      return; // Stop submission
    }

    if (!categoryOid) {
      setErrors((prev) => ({ ...prev, subject: "Category is required" }));
      return;
    }

    if (!subCategoryOid) {
      setErrors((prev) => ({
        ...prev,
        subCategory: "Sub-Category is required",
      }));
      return;
    }

    setIsSubmitting(true);

    try {
      const formData = new FormData();
      formData.append("Title", newTicket.title || "");
      formData.append("Description", newTicket.description || "");
      formData.append("SubjectOid", categoryOid || "");
      formData.append("SubCategoryOid", subCategoryOid || "");
      formData.append("Priority", newTicket.priority || "");
      formData.append("AccountOid", accountOid);
      formData.append("ContactOid", contactOid);
      if (attachmentFile) {
        formData.append("Attachment", attachmentFile, attachmentFile.name);
      }

      await apiService.createTicket(formData);
      if (onSubmit) {
        await onSubmit();
      }
      setToastMessage("Ticket created successfully");

      handleReset();
    } catch (error) {
      console.error("Failed to create ticket", error);
      setSubmitError("Failed to create ticket. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReset = () => {
    setNewTicket({
      title: "",
      subject: "",
      subCategory: "",
      priority: "",
      description: "",
      attachment: "",
    });
    setPreviewUrl(null);
    setAttachmentName("");
    setAttachmentFile(null);
    setCategoryOid("");
    setSubCategoryOid("");
    setErrors({});
    setSubmitError(null);
    onOpenChange(false);
  };

  const selectedCategory = categories.find((cat) => cat.Oid === categoryOid);
  const subCategoryOptions = selectedCategory?.SubCategories ?? [];

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogHeader>
          <DialogTitle>Create New Ticket</DialogTitle>
          <DialogDescription>
            Fill in the details below to submit a new support request.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="grid gap-4 py-4">
          <div className="grid gap-2">
            <Label
              htmlFor="title"
              className={errors.title ? "text-destructive" : ""}
            >
              Title <span className="text-red-500">*</span>
            </Label>
            <Input
              id="title"
              name="title"
              value={newTicket.title}
              onChange={handleInputChange}
              className={
                errors.title
                  ? "border-destructive focus-visible:ring-destructive"
                  : ""
              }
            />
            {errors.title && (
              <p className="text-sm text-destructive">{errors.title}</p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label
                htmlFor="category"
                className={errors.subject ? "text-destructive" : ""}
              >
                Category <span className="text-red-500">*</span>
              </Label>
              <Select
                id="category"
                name="category"
                value={categoryOid}
                onChange={handleCategoryChange}
                className={
                  errors.subject
                    ? "border-destructive focus:ring-destructive"
                    : ""
                }
                disabled={isLoadingCategories}
              >
                <option value="">
                  {isLoadingCategories
                    ? "Loading categories..."
                    : "Select Category"}
                </option>
                {categories.map((cat) => (
                  <option key={cat.Oid} value={cat.Oid}>
                    {cat.Title}
                  </option>
                ))}
              </Select>
              {errors.subject && (
                <p className="text-sm text-destructive">{errors.subject}</p>
              )}
              {categoriesError && (
                <p className="text-sm text-destructive">{categoriesError}</p>
              )}
            </div>
            <div className="grid gap-2">
              <Label
                htmlFor="subCategory"
                className={errors.subCategory ? "text-destructive" : ""}
              >
                Sub-Category <span className="text-red-500">*</span>
              </Label>
              <Select
                id="subCategory"
                name="subCategory"
                value={subCategoryOid}
                onChange={handleSubCategoryChange}
                disabled={!categoryOid}
                className={
                  errors.subCategory
                    ? "border-destructive focus:ring-destructive"
                    : ""
                }
              >
                <option value="">Select Sub-Category</option>
                {subCategoryOptions.map((sub) => (
                  <option key={sub.Oid} value={sub.Oid}>
                    {sub.Title}
                  </option>
                ))}
              </Select>
              {errors.subCategory && (
                <p className="text-sm text-destructive">{errors.subCategory}</p>
              )}
            </div>
          </div>

          <div className="grid gap-2">
            <Label
              htmlFor="priority"
              className={errors.priority ? "text-destructive" : ""}
            >
              Priority <span className="text-red-500">*</span>
            </Label>
            <Select
              id="priority"
              name="priority"
              value={newTicket.priority}
              onChange={handleInputChange}
              className={
                errors.priority
                  ? "border-destructive focus:ring-destructive"
                  : ""
              }
            >
              <option value="">Select Priority</option>
              {PRIORITIES.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </Select>
            {errors.priority && (
              <p className="text-sm text-destructive">{errors.priority}</p>
            )}
          </div>

          <div className="grid gap-2">
            <Label
              htmlFor="description"
              className={errors.description ? "text-destructive" : ""}
            >
              Description <span className="text-red-500">*</span>
            </Label>
            <Textarea
              id="description"
              name="description"
              value={newTicket.description}
              onChange={handleInputChange}
              maxLength={1500}
              className={
                errors.description
                  ? "border-destructive focus-visible:ring-destructive"
                  : ""
              }
            />
            <p className="text-xs text-muted-foreground">
              Note: Max of 1500 characters are allowed only.
            </p>
            {errors.description && (
              <p className="text-sm text-destructive">{errors.description}</p>
            )}
          </div>

          <div className="grid gap-2">
            <Label>Attachment</Label>
            {!previewUrl ? (
              <div className="flex flex-col gap-2">
                <div className="flex items-center justify-center w-full">
                  <label
                    htmlFor="dropzone-file"
                    className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 dark:hover:bg-gray-800 dark:bg-gray-700 border-gray-300 dark:border-gray-600"
                  >
                    <div className="flex flex-col items-center justify-center pt-5 pb-6">
                      <Upload className="w-8 h-8 mb-4 text-gray-500 dark:text-gray-400" />
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        <span className="font-semibold">Click to upload</span>
                      </p>
                    </div>
                    <input
                      id="dropzone-file"
                      type="file"
                      className="hidden"
                      onChange={handleFileChange}
                      accept="image/jpeg, image/png"
                    />
                  </label>
                </div>
                <p className="text-xs text-muted-foreground text-center">
                  Note: Only JPEG or PNG image is allowed. Please upload image
                  below 2MB.
                </p>
                {errors.attachment && (
                  <p className="text-sm text-destructive text-center">
                    {errors.attachment}
                  </p>
                )}
              </div>
            ) : (
              <div className="relative w-[300px] h-[300px] border rounded-md overflow-hidden group mx-auto">
                <img
                  src={previewUrl}
                  alt="Preview"
                  className="w-full h-full object-cover"
                />
                <button
                  type="button"
                  onClick={handleDeleteAttachment}
                  className="absolute top-2 right-2 p-1.5 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            )}
          </div>

          {submitError && (
            <p className="text-sm text-destructive text-center">
              {submitError}
            </p>
          )}

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={handleReset}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Submitting...
                </>
              ) : (
                "Submit Ticket"
              )}
            </Button>
          </DialogFooter>
        </form>
      </Dialog>
      {toastMessage && (
        <div className="fixed bottom-4 right-4 z-50 rounded-md bg-emerald-500 px-4 py-2 text-sm font-medium text-white shadow-lg">
          {toastMessage}
        </div>
      )}
    </>
  );
};
