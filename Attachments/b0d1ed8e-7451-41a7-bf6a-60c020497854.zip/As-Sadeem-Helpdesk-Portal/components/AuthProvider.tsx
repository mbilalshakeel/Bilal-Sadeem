import React, {
  createContext,
  useContext,
  useState,
  ReactNode,
  useEffect,
} from "react";
import { LoginRequest } from "../types";
import apiService from "../services/apiService";

const TOKEN_KEYS = [
  "token",
  "Token",
  "accessToken",
  "AccessToken",
  "jwt",
  "jwtToken",
  "JWTToken",
  "bearerToken",
  "BearerToken",
] as const;

const extractToken = (payload: unknown, depth = 0): string | null => {
  if (!payload || typeof payload !== "object" || depth > 4) {
    return null;
  }

  for (const key of TOKEN_KEYS) {
    const value = (payload as any)[key];
    if (typeof value === "string" && value.trim()) {
      return value.trim();
    }
  }

  for (const value of Object.values(payload)) {
    if (typeof value === "object") {
      const nested = extractToken(value, depth + 1);
      if (nested) {
        return nested;
      }
    }
  }

  return null;
};

interface AuthContextType {
  isAuthenticated: boolean;
  login: (credentials: LoginRequest) => Promise<void>;
  logout: () => void;
  isLoading: boolean;
  error: string | null;
  username: string | null;
  tenantName: string | null;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children?: ReactNode }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [username, setUsername] = useState<string | null>(null);
  const [tenantName, setTenantName] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Check storage on mount to persist session
  useEffect(() => {
    const storedAuth = sessionStorage.getItem("isAuthenticated");
    const storedUser = sessionStorage.getItem("username");
    const storedTenant = sessionStorage.getItem("tenantName");

    if (storedAuth === "true") {
      setIsAuthenticated(true);
      if (storedUser) {
        setUsername(storedUser);
      }
      if (storedTenant) {
        setTenantName(storedTenant);
      }
    }
  }, []);

  const login = async (credentials: LoginRequest) => {
    setIsLoading(true);
    setError(null);

    try {
      // Use the login method which uses separate login API instance
      const response = await apiService.login<any>(
        "helpdesk/authenticate",
        credentials,
      );
      const payload: unknown = response;

      // Extract token from response
      const token =
        typeof payload === "string" ? payload.trim() : extractToken(payload);

      if (!token) {
        throw new Error(
          "Authentication succeeded but token is missing in response payload.",
        );
      }

      apiService.setAuthToken(token);

      // Extract accountOid and contactOid from response
      // Response structure: { success: true, message: "...", data: { token, accountOid, contactOid, ... } }
      let accountOid: string | null = null;
      let contactOid: string | null = null;
      let tenantName: string | null = null;

      if (typeof payload === "object" && payload !== null) {
        const responseObj = payload as any;
        // Check if data exists and contains accountOid and contactOid
        if (responseObj.data) {
          accountOid = responseObj.data.accountOid || null;
          contactOid = responseObj.data.contactOid || null;
          tenantName = responseObj.data.tenantName || null;
        } else {
          // Fallback: check directly on response object
          accountOid = responseObj.accountOid || null;
          contactOid = responseObj.contactOid || null;
          tenantName = responseObj.tenantName || null;
        }
      }

      // Store accountOid and contactOid in sessionStorage
      if (accountOid) {
        sessionStorage.setItem("accountOid", accountOid);
      }
      if (contactOid) {
        sessionStorage.setItem("contactOid", contactOid);
      }
      if (tenantName) {
        sessionStorage.setItem("tenantName", tenantName);
      }

      // Mark user as authenticated if request succeeds
      sessionStorage.setItem("isAuthenticated", "true");
      sessionStorage.setItem("username", credentials.UserName);
      sessionStorage.setItem("tenantName", tenantName);
      setIsAuthenticated(true);
      setUsername(credentials.UserName);
    } catch (err: any) {
      console.error("Login failed", err);
      // Extract error message from API response if available
      const msg =
        err.response?.data?.message ||
        err.response?.data ||
        err.message ||
        "Invalid username or password";
      const errorMsg = typeof msg === "string" ? msg : "Login failed";

      setError(errorMsg);
      throw new Error(errorMsg);
    } finally {
      setIsLoading(false);
    }
  };
  // console.log(setTenantName,"Tenant Name Req")
  const logout = () => {
    apiService.clearAuthToken();
    setIsAuthenticated(false);
    sessionStorage.removeItem("username");
    sessionStorage.removeItem("isAuthenticated");
    sessionStorage.removeItem("accountOid");
    sessionStorage.removeItem("contactOid");
    sessionStorage.removeItem("tenantName");
    setIsAuthenticated(false);
    setUsername(null);
  };

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        username,
        tenantName,
        login,
        logout,
        isLoading,
        error,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
