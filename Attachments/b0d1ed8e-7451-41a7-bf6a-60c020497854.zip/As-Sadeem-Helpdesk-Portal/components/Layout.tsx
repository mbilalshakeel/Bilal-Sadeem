import { ChevronDown, LogOut, Menu, Moon, Sun, User } from "lucide-react";
import React, { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { NAV_ITEMS } from "../constants";
import { Theme } from "../types";
import { useAuth } from "./AuthProvider";
import {
  Button,
  cn,
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  Tooltip,
} from "./ui-kit";

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [theme, setTheme] = useState<Theme>(Theme.LIGHT);
  const { logout, username, tenantName } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  // console.log(username, tenantName, "Check Session storage");
  // console.log()
  useEffect(() => {
    // Check system preference or default to light
    if (window.matchMedia("(prefers-color-scheme: dark)").matches) {
      setTheme(Theme.DARK);
    }
  }, []);

  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove("light", "dark");
    root.classList.add(theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === Theme.LIGHT ? Theme.DARK : Theme.LIGHT));
  };

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  // Replace this URL with your actual logo URL
  const LOGO_URL = "/assets/sadeem-logo.png";

  return (
    <div className="flex min-h-screen bg-background text-foreground transition-colors duration-300">
      {/* Sidebar - Desktop */}
      <aside
        className={cn(
          "hidden md:flex flex-col w-64 border-r border-white/10 bg-[#253746] dark:bg-background text-primary-foreground transition-all duration-300 ease-in-out fixed inset-y-0 z-50",
          !sidebarOpen && "w-16",
        )}
      >
        <div className="h-16 flex items-center justify-center border-b border-white/10 px-4 bg-[#253746] dark:bg-background">
          <div
            className={cn(
              "flex items-center justify-center transition-opacity duration-300 w-full",
              !sidebarOpen && "px-0",
            )}
          >
            {/* Logo Section */}
            {sidebarOpen ? (
              <>
                <img
                  src={LOGO_URL}
                  alt="Helpdesk Logo"
                  className="h-10 w-auto object-contain"
                />
                <p className="ml-5 text-lg font-semibold">Helpdesk</p>
              </>
            ) : (
              // Small icon when collapsed, you might want a smaller version of your logo here
              <img
                src={LOGO_URL}
                alt="Logo"
                className="h-8 w-8 object-cover rounded-full bg-white/10"
              />
            )}
          </div>
        </div>

        <nav className="flex-1 space-y-1 p-2">
          {NAV_ITEMS.map((item) => {
            const isActive = location.pathname === item.href;
            const LinkComponent = (
              <Link
                to={item.href}
                className={cn(
                  "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors",
                  isActive
                    ? "bg-white/20 text-white shadow-none"
                    : "text-white/70 hover:bg-white/10 hover:text-white",
                )}
              >
                <item.icon className="h-4 w-4 shrink-0" />
                <span className={cn("truncate", !sidebarOpen && "hidden")}>
                  {item.title}
                </span>
              </Link>
            );

            return !sidebarOpen ? (
              <React.Fragment key={item.href}>
                <Tooltip content={item.title}>{LinkComponent}</Tooltip>
              </React.Fragment>
            ) : (
              <React.Fragment key={item.href}>{LinkComponent}</React.Fragment>
            );
          })}
        </nav>

        <div
          className={cn(
            "border-t border-white/10 p-4 text-center text-xs text-white/50",
            !sidebarOpen && "hidden",
          )}
        >
          &copy; {new Date().getFullYear()} As-Sadeem Helpdesk. All Rights
          Reserved.
        </div>
      </aside>

      {/* Main Content Area */}
      <main
        className={cn(
          "flex-1 flex flex-col transition-all duration-300",
          sidebarOpen ? "md:ml-64" : "md:ml-16",
        )}
      >
        {/* Header */}
        <header className="h-16 border-b bg-card px-8 flex items-center justify-between sticky top-0 z-40 shadow-sm">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => {}}
            >
              <Menu className="h-5 w-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="hidden md:flex"
              onClick={() => setSidebarOpen(!sidebarOpen)}
            >
              <Menu className="h-5 w-5" />
            </Button>
          </div>

          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={toggleTheme}>
              {theme === Theme.LIGHT ? (
                <Moon className="h-5 w-5" />
              ) : (
                <Sun className="h-5 w-5" />
              )}
            </Button>

            <DropdownMenu>
              <DropdownMenuTrigger>
                <div className="flex items-center gap-2 px-2 py-1 rounded-md hover:bg-accent/50 transition-colors cursor-pointer">
                  <div className="h-8 w-8 bg-black rounded-full flex items-center justify-center">
                    <User className="h-5 w-5 text-white" />
                  </div>
                  <span className="font-bold text-primary text-sm hidden md:inline-block text-transform: uppercase">
                    {username.split("\\").pop() || "User"}
                  </span>
                  <ChevronDown className="h-4 w-4 text-primary" />
                </div>
              </DropdownMenuTrigger>
              <DropdownMenuContent
                align="end"
                className="w-72 p-0 shadow-xl border-gray-200 dark:border-gray-800"
              >
                <div className="flex flex-col items-center p-6">
                  <div className="h-24 w-24 bg-black rounded-full flex items-center justify-center mb-6 shadow-md">
                    <User className="h-12 w-12 text-white" />
                  </div>

                  <div className="w-full space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-500 dark:text-gray-400 font-medium text-sm">
                        User Name :
                      </span>
                      <span className="text-primary font-bold text-sm  text-transform: uppercase">
                        {username.split("\\").pop() || "User"}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-500 dark:text-gray-400 font-medium text-sm">
                        Tenant Name :
                      </span>
                      <span className="text-primary font-bold text-sm">
                        {tenantName || "Tenant"}
                      </span>
                    </div>
                  </div>
                </div>

                <DropdownMenuSeparator className="my-0" />

                <DropdownMenuItem
                  onClick={handleLogout}
                  className="p-4 cursor-pointer text-primary font-bold hover:text-primary hover:bg-gray-50 dark:hover:bg-gray-900 justify-start transition-colors"
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Sign Out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {/* Content */}
        <div className="flex-1 overflow-auto p-0">{children}</div>
      </main>
    </div>
  );
};
