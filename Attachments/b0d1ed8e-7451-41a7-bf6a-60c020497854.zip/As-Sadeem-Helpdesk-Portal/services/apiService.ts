import axios, {
  AxiosHeaders,
  AxiosInstance,
  AxiosRequestConfig,
  AxiosResponse,
} from "axios";
import { Reply, Ticket, TicketCategory } from "../types";

interface ApiTicket {
  Oid?: string;
  TicketId?: string;
  Title?: string;
  Description?: string;
  Subject?: string;
  Status?: string;
  Priority?: string;
  TicketDate?: string;
  ClosingDate?: string;
  Attachment?: string | null;
  AttachmentName?: string | null;
  Replies?: any[];
  Account?: string | null;
  CategoryOid?: string | null;
  SubCategory?: string | null;
  SubCategoryOid?: string | null;
  Category?: string | null;
  [key: string]: any;
}

const normalizeTicket = (item: ApiTicket): Ticket => ({
  oid: item.Oid ?? "",
  ticketId: item.TicketId ?? "",
  title: item.Title ?? "",
  subject: item.Subject ?? "",
  status: item.Status ?? "",
  priority: item.Priority ?? "",
  ticketDate: item.TicketDate ?? "",
  closingDate: item.ClosingDate ?? "",
  description: item.Description ?? "",
  attachment: item.Attachment ?? undefined,
  attachmentName: item.AttachmentName ?? undefined,
  replies: item.Replies as any,
  subCategory: item.SubCategory ?? undefined,
  categoryOid: item.CategoryOid ?? undefined,
  subCategoryOid: item.SubCategoryOid ?? undefined,
  category: item.Category ?? undefined,
});

interface ApiDiscussion {
  Oid?: string;
  CaseID?: string;
  Comment?: string;
  Replay?: string;
  time?: string;
  Date?: string;
  Attachment?: string | null;
  AttachmentName?: string | null;
  RepliedBy?: string | null;
  Username?: string | null;
  PostedBy?: string | null;
  Postedby?: string | null; // Some APIs use different casing
  [key: string]: any;
}

const normalizeDiscussion = (item: ApiDiscussion, index: number): Reply => ({
  id: index + 1,
  sender: item.RepliedBy || item.Username,
  postedBy: item.PostedBy,
  message: item.Comment || item.Replay || "",
  date: item.time || item.Date || "",
  attachment: item.Attachment || undefined,
  attachmentName: item.AttachmentName ?? null,
});

const extractCategoryList = (payload: any): TicketCategory[] => {
  if (Array.isArray(payload)) {
    return payload as TicketCategory[];
  }
  if (payload?.data && Array.isArray(payload.data)) {
    return payload.data as TicketCategory[];
  }
  if (payload?.result && Array.isArray(payload.result)) {
    return payload.result as TicketCategory[];
  }
  if (payload?.categories && Array.isArray(payload.categories)) {
    return payload.categories as TicketCategory[];
  }
  return [];
};

// Base URLs
// Login API uses the original baseURL
const LOGIN_BASE_URL = process.env.NEXT_PUBLIC_LOGIN_API_URL || "/api1/";
// process.env.NEXT_PUBLIC_LOGIN_API_URL || "http://10.169.223.94:5000/api/";

// All other APIs use the new baseURL
const BASE_URL = process.env.NEXT_PUBLIC_API_URL || "/api2/";
// public
// process.env.NEXT_PUBLIC_API_URL || "http://10.169.223.35:5003/api/";

// Create separate axios instance for login API
const loginApi: AxiosInstance = axios.create({
  baseURL: LOGIN_BASE_URL,
  // timeout: 10000,
});

// Create axios instance with default configuration for other APIs
const api: AxiosInstance = axios.create({
  baseURL: BASE_URL,
  // timeout: 10000,
  // headers: {
  //   "Content-Type": "application/json",
  // },
});

// Request interceptor to add authentication token
api.interceptors.request.use(
  (config) => {
    // Get token from session storage
    const token =
      typeof window !== "undefined"
        ? sessionStorage.getItem("authToken")
        : null;

    if (token) {
      config.headers = AxiosHeaders.from(config.headers || {});
      config.headers.set("Authorization", `Bearer ${token}`);
    }

    return config;
  },
  (error) => {
    return Promise.reject(error);
  },
);

// Response interceptor for error handling
api.interceptors.response.use(
  (response: AxiosResponse) => {
    return response;
  },
  (error) => {
    // Handle common errors
    if (error.response?.status === 401) {
      // Unauthorized - clear session and redirect to login
      if (typeof window !== "undefined") {
        sessionStorage.removeItem("authToken");
        sessionStorage.removeItem("isAuthenticated");
        // Only redirect if not already on login page to avoid loops
        if (!window.location.hash.includes("login")) {
          window.location.href = "/#/login";
        }
      }
    }

    return Promise.reject(error);
  },
);

// Generic API service class
class ApiService {
  // GET request
  async get<T = any>(url: string, config?: AxiosRequestConfig): Promise<T> {
    const response = await api.get<T>(url, config);
    return response.data;
  }

  // POST request
  async post<T = any>(
    url: string,
    data?: any,
    config?: AxiosRequestConfig,
  ): Promise<T> {
    const response = await api.post<T>(url, data, config);
    return response.data;
  }

  // POST FormData request
  async postForm<T = any>(
    url: string,
    data: FormData,
    config?: AxiosRequestConfig,
  ): Promise<T> {
    const response = await api.post<T>(url, data, config);
    return response.data;
  }

  // PUT request
  async put<T = any>(
    url: string,
    data?: any,
    config?: AxiosRequestConfig,
  ): Promise<T> {
    const response = await api.put<T>(url, data, config);
    return response.data;
  }

  // PATCH request
  async patch<T = any>(
    url: string,
    data?: any,
    config?: AxiosRequestConfig,
  ): Promise<T> {
    const response = await api.patch<T>(url, data, config);
    return response.data;
  }

  // DELETE request
  async delete<T = any>(url: string, config?: AxiosRequestConfig): Promise<T> {
    const response = await api.delete<T>(url, config);
    return response.data;
  }

  // Set authentication token
  setAuthToken(token: string): void {
    if (typeof window !== "undefined") {
      sessionStorage.setItem("authToken", token);
    }

    api.defaults.headers.common["Authorization"] = `Bearer ${token}`;
  }

  // Clear authentication token
  clearAuthToken(): void {
    if (typeof window !== "undefined") {
      sessionStorage.removeItem("authToken");
      sessionStorage.removeItem("isAuthenticated");
      sessionStorage.removeItem("accountOid");
      sessionStorage.removeItem("contactOid");
      sessionStorage.removeItem("tenantName");
    }

    delete api.defaults.headers.common["Authorization"];
  }

  // Get authentication token
  getAuthToken(): string | null {
    if (typeof window !== "undefined") {
      return sessionStorage.getItem("authToken");
    }
    return null;
  }

  /**
   * Fetch tickets based on account and contact IDs and type.
   * @param username - The currently logged-in user (kept for backward compatibility, not sent to API).
   * @param ticketType - 'Open', 'Resolved', or null for all.
   */
  async getTickets(
    username: string,
    ticketType?: string | null,
  ): Promise<Ticket[]> {
    // Get accountOid and contactOid from sessionStorage (required parameters)
    let accountOid: string | null = null;
    let contactOid: string | null = null;

    if (typeof window !== "undefined") {
      accountOid = sessionStorage.getItem("accountOid");
      contactOid = sessionStorage.getItem("contactOid");
    }

    // Validate required parameters
    if (!accountOid) {
      throw new Error("AccountID is required. Please login again.");
    }
    if (!contactOid) {
      throw new Error("ContactID is required. Please login again.");
    }

    // Build params with required fields: AccountID, ContactID, and TicketType
    const params: any = {
      AccountID: accountOid,
      ContactID: contactOid,
      TicketType: ticketType !== undefined ? ticketType : null,
    };

    // Note: The API endpoint provided is CasesApi
    const rawData = await this.get<ApiTicket | ApiTicket[]>("CasesApi", {
      params,
    });
    const collection = Array.isArray(rawData)
      ? rawData
      : rawData
        ? [rawData]
        : [];
    return collection.map(normalizeTicket);
  }

  async getCategories(): Promise<TicketCategory[]> {
    const raw = await this.get<any>("categories");
    return extractCategoryList(raw);
  }

  async createTicket(formData: FormData): Promise<any> {
    // Add AccountID and ContactID from sessionStorage to FormData
    // if (typeof window !== "undefined") {
    //   const accountOid = sessionStorage.getItem("accountOid");
    //   const contactOid = sessionStorage.getItem("contactOid");
    //   if (accountOid) {
    //     formData.append("AccountID", accountOid);
    //   }
    //   if (contactOid) {
    //     formData.append("ContactID", contactOid);
    //   }
    // }
    return this.postForm("CasesApi", formData);
  }

  async createDiscussionReply(formData: FormData): Promise<any> {
    return this.postForm("DiscussionsApi", formData);
  }

  async getDiscussions(caseId: string): Promise<Reply[]> {
    const raw = await this.get<ApiDiscussion[]>("DiscussionsApi", {
      params: { caseID: caseId },
    });
    const list = Array.isArray(raw) ? raw : raw ? [raw] : [];
    return list.map(normalizeDiscussion);
  }

  async resolveTicket(caseId: string): Promise<Ticket> {
    // OData pattern: odata/Ticket('{CaseID}')
    const content = { Status: "Resolved" };
    return this.patch<Ticket>(`odata/Ticket/${caseId}`, content);
  }

  // Login method using separate login API instance
  async login<T = any>(
    url: string,
    data?: any,
    config?: AxiosRequestConfig,
  ): Promise<T> {
    const response = await loginApi.post<T>(url, data, config);
    return response.data;
  }
}

// Create and export a singleton instance
const apiService = new ApiService();

export default apiService;
export { api, BASE_URL, LOGIN_BASE_URL, loginApi };
