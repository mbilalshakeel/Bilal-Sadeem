import React from 'react';

export interface NavItem {
  title: string;
  href: string;
  icon: React.ComponentType<{ className?: string }>;
}

export interface MetricCardProps {
  title: string;
  value: string;
  change: string;
  trend: 'up' | 'down' | 'neutral';
  icon: React.ComponentType<{ className?: string }>;
}

export interface RevenueData {
  name: string;
  total: number;
}

export interface RecentSale {
  id: string;
  name: string;
  email: string;
  amount: string;
  avatar: string;
}

export interface AIInsight {
  summary: string;
  recommendation: string;
}

export enum Theme {
  LIGHT = 'light',
  DARK = 'dark'
}

export interface Reply {
  id: number;
  sender: string;
  message: string;
  date: string;
  attachment?: string;
  attachmentName?: string | null;
  postedBy?: string | null;
}

export interface Ticket {
  oid: string;
  ticketId: string;
  title: string;
  subject: string; // Replaces category
  status: string;
  priority: string;
  ticketDate: string; // Replaces creationDate
  closingDate: string;
  description: string;
  attachment?: string;
  attachmentName?: string;
  categoryOid?: string;
  subCategoryOid?: string;
  replies?: Reply[];
  // Optional field for subcategory if UI still needs it, though not in API sample
  subCategory?: string; 
  category: string;
}

export interface TicketCategory {
  Oid: string;
  Title: string;
  SubCategories: Array<{
    Oid: string;
    Title: string;
  }>;
}

export interface CategoryMap {
  [key: string]: string[];
}

export interface LoginRequest {
  UserName: string;
  Password: string;
}

export interface LoginResponse {
  token?: string;
  accessToken?: string;
  [key: string]: any;
}