import {
  CheckCircle,
  HelpCircle,
  Lock,
  Ticket as TicketIcon,
} from "lucide-react";
import { NavItem } from "./types";

export const NAV_ITEMS: NavItem[] = [
  // { title: "Dashboard", href: "/dashboard", icon: Activity },
  { title: "Open Tickets", href: "/tickets/open", icon: TicketIcon },
  { title: "Resolved Tickets", href: "/tickets/closed", icon: Lock },
  { title: "All Tickets", href: "/tickets/all", icon: CheckCircle },
  { title: "FAQs", href: "/faqs", icon: HelpCircle },
  // { title: "License", href: "/license", icon: FileText },
];
export const PRIORITIES = ["Low", "Medium", "High"];